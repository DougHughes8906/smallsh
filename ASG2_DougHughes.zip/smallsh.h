

#ifndef SMALLSH_H
#define SMALLSH_H

// runs a shell with basic functionality
void runShell();

#endif
