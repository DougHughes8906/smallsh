To compile this program, enter "make" into the command line (without the quotation marks). The executable will be named smallsh
