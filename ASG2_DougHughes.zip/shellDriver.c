
#include "smallsh.h"

// run the smallsh shell
int main() {

  runShell();

  return 0;
}
